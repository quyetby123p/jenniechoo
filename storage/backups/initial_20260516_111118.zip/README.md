# Storage Rules

Khong tao file thu cong trong thu muc nay neu co the.
Hay dung `../scripts/new-artifact.ps1` de tao file voi ten duy nhat, tranh ghi de.
